# Rice Retail Boss

A simple Flutter app for rice retail business.