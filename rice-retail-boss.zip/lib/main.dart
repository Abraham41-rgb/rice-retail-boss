import 'package:flutter/material.dart';

void main() {
  runApp(RiceRetailBossApp());
}

class RiceRetailBossApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rice Retail Boss',
      home: Scaffold(
        appBar: AppBar(title: Text('Rice Retail Boss')),
        body: Center(child: Text('Welcome to Rice Retail Boss!')),
      ),
    );
  }
}
