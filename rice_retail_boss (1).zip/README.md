# Rice Retail Boss

Flutter project skeleton for RiceRetailBoss app.
