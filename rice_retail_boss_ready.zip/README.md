# Rice Retail Boss

Flutter project skeleton with GitHub Actions ready.
