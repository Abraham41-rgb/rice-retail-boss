import 'package:flutter/material.dart';

void main() {
  runApp(const RiceRetailBossApp());
}

class RiceRetailBossApp extends StatelessWidget {
  const RiceRetailBossApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rice Retail Boss',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rice Retail Boss')),
      body: const Center(
        child: Text(
          'Welcome to Rice Retail Boss!',
          style: TextStyle(fontSize: 22),
        ),
      ),
    );
  }
}
