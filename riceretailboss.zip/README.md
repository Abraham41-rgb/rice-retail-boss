# Rice Retail Boss

Minimal Flutter app to test Codemagic builds.
